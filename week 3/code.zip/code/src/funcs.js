
module.exports = {
    
    myFunction() {
        return "Hello from your API!"
    }

}
